Love-boilerplate
================

boilerplate code from various sources for [Löve](http://www.love2d.org) with typical stuff needed for game jams like [ludum dare](http://www.ludumdare.com/compo/)

Uses the following:
* [hump](https://github.com/vrld/hump) for vectors, gamestates, timers, tweens
* [SLAM](https://github.com/vrld/Stuff/tree/master/slam) for better sound control
* Proxies: on demand resource loading

Thanks go to [VRLD](https://github.com/vrld/)