<?xml version="1.0" encoding="UTF-8"?>
<tileset name="GGJ_background" tilewidth="16" tileheight="16" tilecount="880" columns="40">
 <image source="../img/atlas01.png" width="640" height="360"/>
 <terraintypes>
  <terrain name="Novo Terreno" tile="202"/>
 </terraintypes>
 <tile id="383">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.0909091" width="4.81818" height="15.9091"/>
   <object id="2" x="0.181818" y="0" width="15.8182" height="5"/>
  </objectgroup>
 </tile>
 <tile id="384">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.0909091" width="16" height="4.81818"/>
  </objectgroup>
 </tile>
 <tile id="385">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.0880682" width="15.9091" height="4.91761"/>
   <object id="2" x="11.0085" y="0.122159" width="4.94034" height="15.8523"/>
  </objectgroup>
 </tile>
 <tile id="423">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0" width="5.09091" height="15.9091"/>
  </objectgroup>
 </tile>
 <tile id="424">
  <objectgroup draworder="index">
   <object id="1" x="0.193182" y="0.159091" width="16.0568" height="15.7045"/>
  </objectgroup>
 </tile>
 <tile id="425">
  <objectgroup draworder="index">
   <object id="1" x="11" y="0" width="4.91304" height="16.0435"/>
  </objectgroup>
 </tile>
 <tile id="463">
  <objectgroup draworder="index">
   <object id="3" x="0.03125" y="-0.03125" width="4.96875" height="15.9688"/>
  </objectgroup>
 </tile>
 <tile id="465">
  <objectgroup draworder="index">
   <object id="1" x="10.9565" y="0" width="5.04348" height="15.9565"/>
  </objectgroup>
 </tile>
 <tile id="505">
  <objectgroup draworder="index">
   <object id="1" x="11" y="0" width="5.04348" height="15.9565"/>
  </objectgroup>
 </tile>
 <tile id="545">
  <objectgroup draworder="index">
   <object id="1" x="11.0435" y="0" width="5" height="15.913"/>
   <object id="2" x="0" y="10.9375" width="15.8125" height="4.9375"/>
  </objectgroup>
 </tile>
 <tile id="584">
  <objectgroup draworder="index">
   <object id="1" x="-0.25" y="0.125" width="16.125" height="15.875"/>
  </objectgroup>
 </tile>
 <tile id="585">
  <objectgroup draworder="index">
   <object id="1" x="-0.375" y="-0.375" width="16.25" height="16.375"/>
  </objectgroup>
 </tile>
</tileset>
