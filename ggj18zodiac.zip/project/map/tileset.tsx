<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tileset" tilewidth="8" tileheight="8" tilecount="117" columns="13">
 <image source="../img/tileset.png" width="104" height="72"/>
</tileset>
