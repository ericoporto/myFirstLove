<?xml version="1.0" encoding="UTF-8"?>
<tileset name="objetos" tilewidth="128" tileheight="128" tilecount="27" columns="27">
 <image source="../img/objetos_tileset.png" width="3456" height="128"/>
</tileset>
