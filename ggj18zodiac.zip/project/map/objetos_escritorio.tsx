<?xml version="1.0" encoding="UTF-8"?>
<tileset name="objetos_escritorio" tilewidth="186" tileheight="150" tilecount="27" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="20" height="51" source="../img/escritorio_objetos/sprite_001_Slice.png"/>
 </tile>
 <tile id="1">
  <image width="19" height="34" source="../img/escritorio_objetos/sprite_002_Slice.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="30" source="../img/escritorio_objetos/sprite_003_Slice.png"/>
 </tile>
 <tile id="3">
  <image width="32" height="42" source="../img/escritorio_objetos/sprite_004_Slice.png"/>
 </tile>
 <tile id="4">
  <image width="58" height="34" source="../img/escritorio_objetos/sprite_005_Slice.png"/>
 </tile>
 <tile id="5">
  <image width="34" height="34" source="../img/escritorio_objetos/sprite_006_Slice.png"/>
 </tile>
 <tile id="6">
  <image width="20" height="35" source="../img/escritorio_objetos/sprite_007_Slice.png"/>
 </tile>
 <tile id="7">
  <image width="81" height="40" source="../img/escritorio_objetos/sprite_008_Slice.png"/>
 </tile>
 <tile id="8">
  <image width="60" height="24" source="../img/escritorio_objetos/sprite_009_Slice.png"/>
 </tile>
 <tile id="9">
  <image width="44" height="20" source="../img/escritorio_objetos/sprite_010_Slice.png"/>
 </tile>
 <tile id="10">
  <image width="49" height="20" source="../img/escritorio_objetos/sprite_011_Slice.png"/>
 </tile>
 <tile id="11">
  <image width="17" height="23" source="../img/escritorio_objetos/sprite_012_Slice.png"/>
 </tile>
 <tile id="12">
  <image width="36" height="32" source="../img/escritorio_objetos/sprite_013_Slice.png"/>
 </tile>
 <tile id="13">
  <image width="21" height="23" source="../img/escritorio_objetos/sprite_014_Slice.png"/>
 </tile>
 <tile id="14">
  <image width="18" height="30" source="../img/escritorio_objetos/sprite_015_Slice.png"/>
 </tile>
 <tile id="15">
  <image width="19" height="30" source="../img/escritorio_objetos/sprite_016_Slice.png"/>
 </tile>
 <tile id="16">
  <image width="16" height="25" source="../img/escritorio_objetos/sprite_017_Slice.png"/>
 </tile>
 <tile id="17">
  <image width="30" height="25" source="../img/escritorio_objetos/sprite_018_Slice.png"/>
 </tile>
 <tile id="18">
  <image width="23" height="23" source="../img/escritorio_objetos/sprite_019_Slice.png"/>
 </tile>
 <tile id="19">
  <image width="17" height="30" source="../img/escritorio_objetos/sprite_020_Slice.png"/>
 </tile>
 <tile id="20">
  <image width="14" height="14" source="../img/escritorio_objetos/sprite_021_Slice.png"/>
 </tile>
 <tile id="21">
  <image width="40" height="25" source="../img/escritorio_objetos/sprite_022_Slice.png"/>
 </tile>
 <tile id="22">
  <image width="20" height="29" source="../img/escritorio_objetos/sprite_023_Slice.png"/>
 </tile>
 <tile id="23">
  <image width="72" height="79" source="../img/escritorio_objetos/sprite_024_Slice.png"/>
 </tile>
 <tile id="24">
  <image width="186" height="150" source="../img/escritorio_objetos/sprite_025_Slice.png"/>
 </tile>
 <tile id="25">
  <image width="32" height="42" source="../img/escritorio_objetos/sprite_026_Slice.png"/>
 </tile>
 <tile id="26">
  <image width="37" height="61" source="../img/escritorio_objetos/sprite_027_Slice.png"/>
 </tile>
</tileset>
