<?xml version="1.0" encoding="UTF-8"?>
<tileset name="atlas01" tilewidth="16" tileheight="16" tilecount="880" columns="40">
 <image source="../img/atlas01.png" width="640" height="360"/>
</tileset>
